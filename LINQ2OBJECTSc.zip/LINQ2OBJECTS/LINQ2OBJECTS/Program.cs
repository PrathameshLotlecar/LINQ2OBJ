﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ2OBJECTS
{
    class Program
    {
        static void Main(string[] args)
        {
            #region LINQ_TO_OBJECTS
            //List<string> names = new List<string>
            //{
            //    "Priyanka",
            //    "Prathamesh",
            //    "Neema",
            //    "Nikhil",
            //    "Joe",
            //    "Amit",
            //    "Chaitanya",
            //    "Ashlesha",
            //    "Chandan",
            //    "Neha"
            //};

            //IEnumerable<string> res = (from n in names
            //                           where n.StartsWith("P")
            //                           orderby n descending
            //                           select n).ToList();

            //names.Add("Priya");

            //foreach (string n in res)
            //{
            //    Console.WriteLine(n);
            //} 
            #endregion

            using(EmployeeDataContext ctx = new EmployeeDataContext())
            {
                #region IQueryable
                //IQueryable<EmployeeDetails> res = from e in ctx.EMPLOYEEs
                //          join d in ctx.DEPARTMENTs on e.DEPARTMENTID equals d.DEPARTMENTID
                //          where e.EMPLOYEESALARY > 7000
                //          orderby e.EMPLOYEENAME, e.EMPLOYEESALARY descending
                //          //select e;
                //          select new EmployeeDetails
                //          {
                //              // aliasing
                //              Name = e.EMPLOYEENAME,
                //              Salary = e.EMPLOYEESALARY, // ?? 0.0M
                //              //DeptName = e.DEPARTMENT.DEPARTMENTNAME
                //              DeptName = d.DEPARTMENTNAME
                //          }; 
                #endregion


                #region MEthod_syntax
                //var res = ctx.EMPLOYEEs.Where(e => e.EMPLOYEESALARY > 7000)
                //            .OrderBy(e => e.EMPLOYEENAME)
                //            .ThenByDescending(e => e.EMPLOYEESALARY)
                //            .Select(e => new EmployeeDetails
                //                  {
                //                      // aliasing
                //                      Name = e.EMPLOYEENAME,
                //                      Salary = e.EMPLOYEESALARY, // ?? 0.0M
                //                      //DeptName = e.DEPARTMENT.DEPARTMENTNAME
                //                      DepartmentName = e.DEPARTMENT.DEPARTMENTNAME
                //                  }); 
                #endregion

                //foreach(var emp in res)
                //{
                //    Console.WriteLine("name: " + emp.Name + "\t salary: " + emp.Salary + "\t Department name: " + emp.DeptName);
                //    //Console.WriteLine("name: " + emp.Name + "\t salary: " + emp.Salary + "\t dept: " + emp.DEPARTMENTID);

                //}


                #region SP_Call
                //var result = ctx.USP_GET_EMPLOYEEBYDEPT(2);
                //foreach (var items in result)
                //{
                //    Console.WriteLine("name: " + items.EMPLOYEENAME);
                //    Console.WriteLine("salary: " + items.EMPLOYEESALARY);
                //    Console.WriteLine("Eid: " + items.EMPLOYEEID);
                //    Console.WriteLine("dept: " + items.DEPARTMENTNAME);

                //} 
                #endregion

                #region UpdateEmployee
                //EMPLOYEE objEmployee = new EMPLOYEE();
                //objEmployee.EMPLOYEENAME = "Rahul";
                //objEmployee.EMPLOYEESALARY = 20000;
                //objEmployee.DEPARTMENTID = 2;

                //ctx.EMPLOYEEs.InsertOnSubmit(objEmployee);  // stores in memory

                //ctx.SubmitChanges(); // makes changes to db

                //EMPLOYEE updateEmployee = (from e in ctx.EMPLOYEEs
                //                           where e.EMPLOYEEID == 2
                //                           select e).SingleOrDefault();

                //if (updateEmployee != null)
                //{
                //    updateEmployee.EMPLOYEESALARY += 1000;
                //} 
                #endregion


                #region DeleteEmployee               

                //EMPLOYEE deleteEmployee = (from e in ctx.EMPLOYEEs
                //                           where e.EMPLOYEEID == 2
                //                           select e).SingleOrDefault();

                EMPLOYEE deleteEmployee = ctx.EMPLOYEEs.SingleOrDefault(e => e.EMPLOYEEID == 2);

                if (deleteEmployee != null)
                {                    
                    ctx.EMPLOYEEs.DeleteOnSubmit(deleteEmployee);
                } 
                #endregion


                ctx.SubmitChanges();

            }// ctx.Dispose(); happens automatically.




            //ctx.Dispose();

            Console.ReadKey();
        }
    }
}
