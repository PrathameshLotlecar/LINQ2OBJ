﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ2OBJECTS
{
    class EmployeeDetails
    {
        public string Name { get; set; }

        public decimal ? Salary { get; set; }

        public string DepartmentName { get; set; }
    }
}
